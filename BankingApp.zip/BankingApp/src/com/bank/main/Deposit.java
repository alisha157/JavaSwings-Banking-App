
package com.bank.main;

public interface Deposit {
    
}
