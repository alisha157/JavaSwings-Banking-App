
package com.bank.main;

public interface Withdrawal {
    
}
